const giveItBackLater = (num) => {
    //return num + 1
}

const addSomePromises = (num) => {
    //return num + 1
}

const promiseToGiveItBackLater = (num) => {
    //return num + 1
}

module.exports.giveItBackLater= giveItBackLater
module.exports.addSomePromises= addSomePromises
module.exports.promiseToGiveItBackLater= promiseToGiveItBackLater
