// function groupAdultsByAgeRange (num) {
//     return num + 1
// }

const groupAdultsByAgeRange = (persons) => {
   if(persons.length === 0){
       return {}
   }

    return persons.filter((person) => {
    person.name < 18
    return {}
    })

    
    
}

module.exports.groupAdultsByAgeRange = groupAdultsByAgeRange

