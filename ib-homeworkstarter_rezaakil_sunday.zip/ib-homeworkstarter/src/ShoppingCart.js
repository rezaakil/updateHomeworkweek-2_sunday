

 class ShoppingCart {
    constructor() { 
           //this.cart=cart
           this.cart=[]
    }
    getItems() {
        return this.cart;
    }

    addItem(name,quantity,pricePerUnit) {
        const items ={
            name: name,
            quantity: quantity,
            pricePerUnit: pricePerUnit
        }        
        this.cart.push(items)
    }

    clear(){
       this.cart=[];
    }

    total(){
        let cartTosum =this.cart
        return cartTosum.reduce(function (total, currentValue) {
            return total + currentValue.quantity * currentValue.pricePerUnit;
        }, 0);
    }

}

module.exports= ShoppingCart

